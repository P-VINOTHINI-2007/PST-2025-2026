/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

public class Main{
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Principal (P): ");
        double P = sc.nextDouble();

        System.out.print("Enter Rate of Interest (R): ");
        double R = sc.nextDouble();

        System.out.print("Enter Time (T in years): ");
        double T = sc.nextDouble();

        double SI = (P * R * T) / 100;

        System.out.println("Simple Interest = " + SI);

        sc.close();
    }
}
