/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
package PST_JAVA;

	import java.util.Scanner;

	public class LargestofThreenumbers {
	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter first number: ");
	        int a = sc.nextInt();

	        System.out.print("Enter second number: ");
	        int b = sc.nextInt();

	        System.out.print("Enter third number: ");
	        int c = sc.nextInt();

	        if (a >= b && a >= c) {
	            System.out.println("Largest number is: " + a);
	        } else if (b >= a && b >= c) {
	            System.out.println("Largest number is: " + b);
	        } else {
	            System.out.println("Largest number is: " + c);
	        }

	        sc.close();
	    }
	}



