/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
package PST_JAVA;

public class Hybrid {

	public static void main(String[] args) {
		

	}

}
class ClassA{
	void Vinothini() {
		System.out.print("She is  a Girl");
	}
}
class ClassB extends ClassA{
	void Sridevi() {
		System.out.print("She is my Friend");
	}
	
}
class ClassC  extends ClassA{
	void Ewans() {
		System.out.print("she is a miniki");
	}
	
}
class  ClassD extends ClassA{
	void Dhan() {
		System.out.print("She is pall alagi");
	}
}
class ClassE extends ClassA{
	void Ranjana() {
		System.out.print("She is my friend");
	}
}
