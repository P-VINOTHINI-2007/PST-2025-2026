
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the value:");
        int num = sc.nextInt();

        Horizontal(num);
        System.out.println(); 
        Vertical(num);

        sc.close();
    }

   
    static void Horizontal(int num) {
        for (int i = 0; i < num; i++) {
            System.out.print("* ");
        }
    }

    
    static void Vertical(int num) {
        for (int i = 0; i < num; i++) {
            System.out.println("*");
        }
    }
}


