/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
package PST_JAVA;
import java.util.Scanner;


public class MultiplicationTable {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the Number:");
	int num=sc.nextInt();
	for(int i=1;i<=16;i++) {
		System.out.println(num + " x " + i + " = " + (num * i));
    }
	}
	

	}


