/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 public class Main  {
    public static void main(String[] args) {

        int a = 10;

        System.out.println("Original value: " + a);

        System.out.println("Unary plus: " + (+a));
        System.out.println("Unary minus: " + (-a));

        a++;
        System.out.println("After increment: " + a);

        a--;
        System.out.println("After decrement: " + a);

        boolean flag = true;
        System.out.println("Logical NOT: " + (!flag));
    }
}
