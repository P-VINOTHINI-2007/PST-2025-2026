/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
package PST_JAVA;
import java.util.Scanner;

public class ArmstrongNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        
        int remainder;
        int result = 0;
        int digits = 0;
        int temp = num;

        
        while (temp != 0) {
            temp = temp / 10;
            digits++;
        }

        temp = num;

     
        while (temp != 0) {
            remainder = temp % 10;
            result += Math.pow(remainder, digits);
            temp = temp / 10;
        }

        if (result == num) {
            System.out.println(num + " is an Armstrong number");
        } else {
            System.out.println(num + " is NOT an Armstrong number");
        }
    }
