/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
package PST_JAVA;

public class Oops {
	

	public static void main(String[] args) {
	        Oops obj1 = new Oops();
	        ThirdyearIT obj2 = new ThirdyearIT();
	        obj2.Surya();
	        obj2.Srihari();
	        obj1.Dhanya();
	      
	        }
	
	public  void Ewansangel() {
		System.out.println("minukki");	
		}
	public  void Sri() {
		System.out.println("penthaaney");
	}
	public  void Vino() {
		System.out.println("silent girl");
		
	}
	public  void Manjima() {
		System.out.println("good girl");
	}
	public void Dhanya() {
		System.out.println("pallazhagi");
	}

}
class ThirdyearIT{
	
	

	public void Surya() {
		System.out.println("Representative");
	}
	public void Srikanth() {
		System.out.println("mottai");
	}
	public void Srihari() {
		System.out.println("valathavan");
	}
	public void Johnisaac() {
		System.out.println("Don john");
	}
	
	

}

