/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


public class Main {

	public static void main(String[] args) {
		ClassB obj1=new ClassB();
		obj1.CSE();
		
	

	}

}
class ClassA {
	void IT() {
		System.out.print("Information Technology");
		
	}
}
class ClassB extends ClassA{
	void CSE() {
		System.out.print("Computer Science And Engineering");
		
	}
}
class ClassC extends ClassB{
	void ECE() {
		System.out.print("Electronical Communication Engineering");
	}
}
class ClassD extends ClassC{
	void BME() {
		System.out.print("Biomedical Eng");
	}
}
